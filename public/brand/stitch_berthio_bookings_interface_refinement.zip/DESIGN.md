---
name: Berthio Marina OS
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434656'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737688'
  outline-variant: '#c3c5d9'
  surface-tint: '#004ced'
  primary: '#003ec7'
  on-primary: '#ffffff'
  primary-container: '#0052ff'
  on-primary-container: '#dfe3ff'
  inverse-primary: '#b7c4ff'
  secondary: '#006398'
  on-secondary: '#ffffff'
  secondary-container: '#5bb8fe'
  on-secondary-container: '#00476e'
  tertiary: '#952200'
  on-tertiary: '#ffffff'
  tertiary-container: '#bf3003'
  on-tertiary-container: '#ffddd5'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b7c4ff'
  on-primary-fixed: '#001452'
  on-primary-fixed-variant: '#0038b6'
  secondary-fixed: '#cce5ff'
  secondary-fixed-dim: '#93ccff'
  on-secondary-fixed: '#001d31'
  on-secondary-fixed-variant: '#004b73'
  tertiary-fixed: '#ffdbd2'
  tertiary-fixed-dim: '#ffb4a1'
  on-tertiary-fixed: '#3c0800'
  on-tertiary-fixed-variant: '#891e00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-base:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-medium:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  body-compact:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  tabular-data:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.06em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  sidebar-width: 16rem
  sidebar-collapsed-width: 4.5rem
  pad-xs: 0.25rem
  pad-sm: 0.5rem
  pad-md: 0.75rem
  pad-lg: 1rem
  pad-xl: 1.5rem
  gap-default: 1rem
  header-height: 3.5rem
---

## Brand & Style

This design system serves a high-density, mission-critical operations environment: managing slips, vessels, utility metering, and transient dockage in real time. Harbor masters and dock personnel operate under varied lighting conditions, requiring immediate visual comprehension, zero decorative ambiguity, and reliable data density.

The visual style is **Corporate / Modern utilitarian with nautical precision**:
- Crisp, clinical structure utilizing pure white cards over an off-white maritime slate canvas.
- Functional color encoding where every hue maps strictly to an operational state (Available, Occupied, Blocked, Maintenance).
- Restrained, instrument-grade chrome: no soft drop-shadow noise, no ornamental charts, and no decorative iconography. Visual weight is reserved strictly for operational telemetry and vessel status.

## Colors

Color is applied systematically to minimize cognitive load during busy dock rotations:

### Core Palette
- **Primary Brand**: `#0052FF` (Electric Blue) — Reserved for the primary navigation shell, active selection rings, and core call-to-actions.
- **Primary Hover / Active**: `#0045D8` — Deepened blue for sustained interactions.
- **Navigation Active Tile**: `#1D68FF` — Translucent tint on solid electric blue.
- **Canvas / Background**: `#F8FAFC` (Slate 50) — High-legibility, glare-reducing cool neutral.
- **Surface**: `#FFFFFF` — Cards, modals, slide-overs, and popovers.
- **Borders & Dividers**: `#E2E8F0` (Slate 200) — Structural dividing line for all layout grids and containers.
- **Primary Text**: `#0F172A` (Slate 900) — Ultra-crisp contrast for vessel names, LOA, and berth numbers.
- **Secondary / Muted Text**: `#64748B` (Slate 500) — Metadata, timestamps, units, and structural labels.

### Operational State Tokens
Status colors must always be rendered as a trio (Text, Background, Border) to ensure legibility across various screen angles:
- **Available / Active**: Text `#10B981`, Background `#ECFDF5`, Border `#A7F3D0`
- **Occupied / Neutral**: Text `#0284C7`, Background `#F0F9FF`, Border `#BAE6FD`
- **Blocked / Warning**: Text `#F59E0B`, Background `#FFFBEB`, Border `#FDE68A`
- **Out of Service / Critical**: Text `#EF4444`, Background `#FEF2F2`, Border `#FECACA`

## Typography

The typography uses Inter across all viewports to provide clear, tabular-first UI rendering:
- Enable font feature settings `tnum` (tabular numbers) for all dimensions, LOA, beam, draft measurements, berth IDs, timestamps, and currency values.
- Table headers and section overheads utilize `label-caps`: bold 11px uppercase with `0.06em` letter spacing for fast horizontal scanning across wide operational grids.
- Body sizes remain strictly between 13px and 14px to balance information density with touch targets.

## Layout & Spacing

The workspace uses a primary 2-column operational layout structured for high-throughput workflows:

1. **Global Navigation Column**:
   - Fixed 256px (`16rem`) sidebar anchored to the left.
   - Finished in solid `#0052FF` Electric Blue.
   - Contains branding at top, vertical operational navigation in the center, and pinned workspace selector and user profile pill at the base.

2. **Operational 2-Column Main Stage**:
   - Spans the remaining viewport width, padded with `1.5rem` (`pad-xl`).
   - Divided into a responsive 2-column layout:
     - **Primary Master Grid (60–65%)**: Live dock manifests, berth lists, or interactive slip matrices.
     - **Secondary Inspector / Detail Panel (35–40%)**: Selected vessel dossier, utility readings, arrivals/departures queue, and billing summaries.
   - On screens under 1024px, the inspector stacks underneath or transitions into an anchored right-hand slide-over sheet.

## Elevation & Depth

This design system avoids blurry shadows in favor of crisp borders and precise spatial containment:
- **Base Surface**: Crisp `#E2E8F0` 1px solid borders on `#FFFFFF` surfaces establish contrast against the `#F8FAFC` page backdrop.
- **Hover & Interaction**: No elevation lifting; interaction is signaled through border shifts (from `#E2E8F0` to `#CBD5E1` or `#0052FF`) and subtle surface fills (`#F1F5F9`).
- **Floating Overlays & Popovers**: Reserved only for action dropdowns, popovers, and dialogs. Structured with `border: 1px solid #E2E8F0` and a compact, tight-radius drop shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.

## Shapes

The interface balances modern geometry with dense industrial data display:
- **Cards and Containers**: Set to `rounded-xl` (`0.75rem` / 12px) to softly frame dense operational modules while retaining crisp vertical and horizontal edges.
- **Controls & Form Fields**: Set to standard `rounded` (`0.375rem` / 6px) to maintain a compact, tool-like appearance.
- **Pills & Status Indicators**: Full rounded pill (`9999px`) for badges, state indicators, and the bottom profile avatar container.

## Components

### Buttons
- **Primary**: Solid `#0052FF` background, `#FFFFFF` text, `font-weight: 500`. Hover state `#0045D8`. Focused state has a 2px offset ring with `#0052FF`.
- **Secondary / Outline**: `#FFFFFF` background, `#0F172A` text, `border: 1px solid #E2E8F0`. Hover state `#F8FAFC`.
- **Destructive**: `#FEF2F2` background, `#EF4444` text, `border: 1px solid #FECACA`. Hover state `#FEE2E2`.
- **Sizing**: Height 36px (default), 32px (compact grid actions).

### Status Badges & Chips
- Structure: 22px fixed height, pill-shaped (`rounded-full`), padded `0.5rem` horizontally.
- Layout: 6px solid dot indicator aligned left of the uppercase label.
- Four mandatory operational states:
  1. *Available*: `#ECFDF5` background, `#10B981` text, `#A7F3D0` border.
  2. *Occupied*: `#F0F9FF` background, `#0284C7` text, `#BAE6FD` border.
  3. *Warning / Blocked*: `#FFFBEB` background, `#F59E0B` text, `#FDE68A` border.
  4. *Out of Service*: `#FEF2F2` background, `#EF4444` text, `#FECACA` border.

### Operational Cards
- Background `#FFFFFF`, `border: 1px solid #E2E8F0`, `border-radius: 0.75rem` (`rounded-xl`).
- Internal header bar padded `0.75rem 1rem` with a subtle bottom divider `border-b: 1px solid #E2E8F0`.
- Card body uses `pad-lg` (`1rem`) with zero inner shadows.

### Tables & Manifest Lists
- Header Row: `#F8FAFC` background, `border-b: 1px solid #E2E8F0`. Typography is strict `label-caps` (`#64748B`).
- Body Rows: Height 44px, alternating hover state `#F8FAFC`, active selection state `#F0F9FF` with `#0052FF` left accent border.
- Data Cells: Rendered in `tabular-data` style (`#0F172A`), ensuring numbers, vessel dimensions, and dates remain aligned.

### Form Inputs & Selects
- Height 36px, `border: 1px solid #E2E8F0`, background `#FFFFFF`, text `#0F172A`.
- Focus state: `border-color: #0052FF`, `box-shadow: 0 0 0 1px #0052FF`.
- Placeholder text: `#94A3B8`.

### Navigation Shell
- Sidebar Background: `#0052FF` Electric Blue.
- Nav Items: 38px height, `rounded-md`, `#FFFFFF` with 80% opacity.
- Nav Item Active: `#1D68FF` background, pure `#FFFFFF` text, bold weight with a white indicator icon.
- Bottom Profile Pill: Surface container with translucent fill `rgba(255, 255, 255, 0.12)`, holding user initials, current marina branch switcher, and system status indicator.